package org.jeecg.modules.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.jeecg.modules.system.entity.SysTenant;

public interface SysTenantMapper extends BaseMapper<SysTenant> {

}
